---
title: 一个极简且美观的多用户网盘程序：Veno-File-Manager-V3-4-8
sticky: 3
toc: true
toc_number: true
auto_open: true
categories: 
- 服务器
- 网盘
description: 说明：`Veno File Manager`估计很多人用过，极简而且功能强大，安装也简单，只要支持`PHP`即可，无需数据库。
cover: 'https://imgkr.cn-bj.ufileos.com/86b8a138-f131-48bc-84ad-cf812d9b4cd8.png'
copyright: false
abbrlink: 61037
date: 2020-06-15 10:58:57
updated:
tags:
keywords:
top_img:
secret:
comments:
mathjax:
katex:
aplayer:
highlight_shrink:
password:
hidden:
---



# 一个极简且美观的多用户网盘程序：Veno File Manager V3.4.8

说明：`Veno File Manager`估计很多人用过，极简而且功能强大，安装也简单，只要支持`PHP`即可，无需数据库，只是需要花钱购买，目前官方更新到了`V3.4.5`，这里就分享由[顶点网](https://www.topide.com/)破解的`Veno File Manager V3.4.5`程序，博主用了下，相比较以前老版本，更新还是挺多的，详细介绍可以查看官网→[传送门](https://filemanager.veno.it/)。

> 提示：目前最新版为V3.4.8，已在文中分享出来。

## 截图


![](https://imgkr.cn-bj.ufileos.com/86b8a138-f131-48bc-84ad-cf812d9b4cd8.png)

![](https://imgkr.cn-bj.ufileos.com/e870a6e8-2db9-49dc-b184-318dc44404bf.png)

![](https://imgkr.cn-bj.ufileos.com/bebf5954-3a96-435c-8c27-8b927cf440fc.png)

![](https://imgkr.cn-bj.ufileos.com/05164471-3383-4afe-a45e-c9edad95e06e.png)


## 安装
所需环境：`Nginx/Apache`、`PHP`
程序下载：[veno-file-manager-v3.4.5.zip](https://www.moerats.com/usr/down/veno-file-manager-v3.4.5.zip)、[veno-file-manager-v3.4.8.zip](https://www.moerats.com/usr/down/veno-file-manager-v3.4.8.zip)

先搭建好环境，然后将源码上传到网站根目录即可，默认登录管理的用户名是`admin`密码是`password`，进后台后记得设置一下语言和更改密码。

如果你过于小白，还不会搭建环境，可以参考该建站教程→[传送门](https://www.moerats.com/archives/778/)。

> 文章转载自[Rat's Blog](https://www.moerats.com/archives/781/) 转载请注明出处！